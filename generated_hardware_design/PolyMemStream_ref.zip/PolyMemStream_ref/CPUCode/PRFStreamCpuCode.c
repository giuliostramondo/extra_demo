# include <unistd.h>
# include <float.h>
# include <limits.h>
# include <sys/time.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#include "Maxfiles.h"
#include "MaxSLiCInterface.h"

#include "schedule_utils.h"
#include "tests.h"

#define    LOAD 0
#define    OFFLOAD 1
#define    COMPUTE 2

//Declarations taken from stream benchmark
//TODO set below to 87040
#ifndef STREAM_ARRAY_SIZE
#   define STREAM_ARRAY_SIZE	87040
#endif

#ifndef OFFSET
#   define OFFSET	0
#endif

#ifdef NTIMES
#if NTIMES<=1
#   define NTIMES	10
#endif
#endif
#ifndef NTIMES
#   define NTIMES	10
#endif

# define HLINE "-------------------------------------------------------------\n"

# ifndef MIN
# define MIN(x,y) ((x)<(y)?(x):(y))
# endif
# ifndef MAX
# define MAX(x,y) ((x)>(y)?(x):(y))
# endif


#define STREAM_TYPE double


static double	avgtime[6] = {0}, maxtime[6] = {0},
		mintime[6] = {FLT_MAX,FLT_MAX,FLT_MAX,FLT_MAX,FLT_MAX,FLT_MAX};

static char	*label[6] = {"Load:      ","Offload:   ","Copy:      ", "Scale:     ",
    "Add:       ", "Triad:     "};

static double	bytes[6] = {
    3 * sizeof(STREAM_TYPE) * STREAM_ARRAY_SIZE,
    3 * sizeof(STREAM_TYPE) * STREAM_ARRAY_SIZE,
    2 * sizeof(STREAM_TYPE) * STREAM_ARRAY_SIZE,
    2 * sizeof(STREAM_TYPE) * STREAM_ARRAY_SIZE,
    3 * sizeof(STREAM_TYPE) * STREAM_ARRAY_SIZE,
    3 * sizeof(STREAM_TYPE) * STREAM_ARRAY_SIZE
    };

double mysecond()
{
/* struct timeval { long        tv_sec;
            long        tv_usec;        };

struct timezone { int   tz_minuteswest;
             int        tz_dsttime;      };     */

        struct timeval tp;
        struct timezone tzp;
        int i;

        i = gettimeofday(&tp,&tzp);
        return ( (double) tp.tv_sec + (double) tp.tv_usec * 1.e-6 );
}

#define M 512
#define N 512
#define p 2 
#define q 4


int main(int argc, char *argv[])
{
        int schedule_len = 0;
        Schedule *s = NULL;
        if(argc > 1 ){
            char *scheduleFile = argv[1];
            schedule_len = getFileLenght(scheduleFile);
            s = parseSchedule(scheduleFile);
        }

        int size = 87040;
        int num_copy=1;
        int scheduleROMsize=(M*N/p*q);
        int *scheduleROM=NULL;

        if (s != FILE_NOT_FOUND)
            scheduleROM = compress_schedule_toROM(s,schedule_len,p*q,scheduleROMsize);
        else
            scheduleROM = malloc(scheduleROMsize*sizeof(int));
        
        int sizeBytes = size * sizeof(STREAM_TYPE);
        STREAM_TYPE *a = malloc(sizeBytes);
        STREAM_TYPE *b = malloc(sizeBytes);
        STREAM_TYPE *c = malloc(sizeBytes);
        STREAM_TYPE *aOut = malloc(sizeBytes);
        STREAM_TYPE *bOut = malloc(sizeBytes);
        STREAM_TYPE *cOut = malloc(sizeBytes);


        // Generate input data
        for(int i = 0; i < size; ++i) {
                a[i] = i;
                b[i] = i;
                c[i] = -1;
        }
        
        //Initialize Hardware design Parameters
        PRFStream_actions_t prfStreamInput;
        prfStreamInput.param_VEC_SIZE=size;
        prfStreamInput.param_copy_repeats= num_copy;
        prfStreamInput.param_prfMode=LOAD;
        //Do not use the schedule for loading/Offloading
        prfStreamInput.param_scheduleROMsize=0;
        prfStreamInput.instream_aStream=a;
        prfStreamInput.instream_bStream=b;
        prfStreamInput.instream_cStream=c;
        prfStreamInput.outstream_aOutStream=aOut;
        prfStreamInput.outstream_bOutStream=bOut;
        prfStreamInput.outstream_cOutStream=cOut;
        prfStreamInput.inmem_PRFStreamKernel_ScheduleROM=scheduleROM;
        
        //Load bitstream on fpga
        max_file_t* StreamMaxFile =  PRFStream_init();
        max_engine_t* StreamDFE=max_load(StreamMaxFile,"*");


         PRFStream_run(StreamDFE,&prfStreamInput);

        
        printf("Running on DFE.\n");

            printf("Loading ... \n");
            prfStreamInput.param_prfMode=LOAD;
            PRFStream_run(StreamDFE,&prfStreamInput);

            printf("Offloading ... \n");
            prfStreamInput.param_prfMode=OFFLOAD;
            PRFStream_run(StreamDFE,&prfStreamInput);

            printf("Checking correctness load/offload ... \n");
            //Check correctness of load/offload
            int error=0;
            for(int i = 0; i < size; ++i)
                    if ( a[i] != aOut[i] || b[i] != bOut[i] || c[i] != cOut[i]){
                        error=1;
                        printf("Load/Offload error %f , %f , %f , %f , %f , %f \n",a[i] , aOut[i] , b[i] , bOut[i] , c[i] , cOut[i]);
                    }

            if(error){
                printf("Errors were found during loading/offloading\n");
            }
            //Use the schedule (if provided) to run the STREAM kernel
            prfStreamInput.param_scheduleROMsize=schedule_len;
           printf ("schedule size: %d",schedule_len); 
            printf("Compute benchmark ... \n");
            prfStreamInput.param_prfMode=COMPUTE;
            PRFStream_run(StreamDFE,&prfStreamInput);
            //Check correctness of copy benchmark
            printf("Checking correctness: Offloading ... \n");
            prfStreamInput.param_prfMode=OFFLOAD;
            PRFStream_run(StreamDFE,&prfStreamInput);



        printf("Done.\n");

        //printing c output

        for(int i = 0; i < size; ++i) {
        
        printf("%d %f\n",i,cOut[i]);
        }
        return 0;
}

